//
//  HJTableViewCell.m
//  SDAutoLayout_learn
//
//  Created by 四川艺匠天诚科技有限公司 on 16/8/11.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import "HJTableViewCell.h"
#import "SDAutoLayout.h"

#define kMAIN_SCREEN      ([UIScreen mainScreen].bounds.size.height*1.0)/[UIScreen mainScreen].bounds.size.width
#define kIPHONE6_SCREEN   375/667.0
#define kSALE kMAIN_SCREEN*kIPHONE6_SCREEN
@implementation HJTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setup];
        
    }
    return self;
}

- (void)setup{
//    UIImageView *headerImageView = [UIImageView new];
//    _headerImageView = headerImageView;
//    
//    UILabel *nickNameLabel = [UILabel new];
//    _nickNameLabel = nickNameLabel;
//    
//    UILabel *contentLabel = [UILabel new];
//    _contentLabel = contentLabel;
//    
//    UIImageView *contentImage = [UIImageView new];
 //   _contentImage = contentImage;
    _headerImageView = [UIImageView new];
    _nickNameLabel = [UILabel new];
    _contentLabel = [UILabel new];
    _contentImage = [UIImageView new];
    [self.contentView sd_addSubviews:@[_headerImageView,_nickNameLabel,_contentLabel,_contentImage]];

    _headerImageView.sd_layout
    .heightIs(50*kSALE)
    .widthEqualToHeight()
    .topSpaceToView(self.contentView,10)
    .leftSpaceToView(self.contentView,10);
    _headerImageView.sd_cornerRadiusFromWidthRatio = @(0.5);
    
    _nickNameLabel.sd_layout
    .autoHeightRatio(0)
    .leftSpaceToView(_headerImageView,10)
    .topEqualToView(_headerImageView)
    .rightSpaceToView(self.contentView,10);
    //_nickNameLabel.numberOfLines = 1;
    _nickNameLabel.font = [UIFont systemFontOfSize:16*kSALE];
    
    _contentLabel.sd_layout
    .autoHeightRatio(0)
    .leftEqualToView(_nickNameLabel)
    .topSpaceToView(_nickNameLabel,10)
    .rightSpaceToView(self.contentView,10);
    
    _contentLabel.numberOfLines = 0;
    _contentLabel.font = [UIFont systemFontOfSize:14*kSALE];
    NSLog(@"fff%f",14*kSALE);
    
    _contentImage.sd_layout
    .topSpaceToView(_contentLabel,10)
    .leftEqualToView(_contentLabel)
    .widthRatioToView(_contentLabel, 0.7);
//    [_contentLabel setSingleLineAutoResizeWithMaxWidth:0];
}

- (void)setModel:(HJModel *)model{
    _model = model;
    _headerImageView.image = [UIImage imageNamed:model.headerImageView];
    _nickNameLabel.text    = model.nickName;
    _contentLabel.text     = model.contentString;
    _contentImage.image    = [UIImage imageNamed:model.contentImageView];
    
    float buttomMargin = 0;
    
    UIImage *contentPic = [UIImage imageNamed:model.contentImageView];

    if (contentPic.size.width>0) {
        float scale = contentPic.size.height*1.0/contentPic.size.width;
        _contentImage.sd_layout
        .autoHeightRatio(scale)
       ;
        buttomMargin = 10;
    }else{
        _contentImage.sd_layout
        .autoHeightRatio(0)
        ;
    }
    [self setupAutoHeightWithBottomView:_contentImage bottomMargin:10];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
