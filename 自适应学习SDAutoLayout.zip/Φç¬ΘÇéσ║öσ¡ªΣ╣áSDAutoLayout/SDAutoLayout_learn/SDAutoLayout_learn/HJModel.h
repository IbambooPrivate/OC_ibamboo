//
//  HJModel.h
//  SDAutoLayout_learn
//
//  Created by 四川艺匠天诚科技有限公司 on 16/8/11.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HJModel : NSObject

@property (nonatomic, copy) NSString *headerImageView;
@property (nonatomic, copy) NSString *nickName;
@property (nonatomic, copy) NSString *contentString;
@property (nonatomic, copy) NSString *contentImageView;

@end
