
//
//  HJTableViewCell.h
//  SDAutoLayout_learn
//
//  Created by 四川艺匠天诚科技有限公司 on 16/8/11.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HJModel.h"
@interface HJTableViewCell : UITableViewCell
//@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
//@property (weak, nonatomic) IBOutlet UIImageView *contentImage;
//@property (weak, nonatomic) IBOutlet UILabel *nickNameLabel;
//@property (weak, nonatomic) IBOutlet UIImageView *headerImageView;
@property (strong, nonatomic)  UIImageView *headerImageView;
@property (strong, nonatomic)  UILabel *nickNameLabel;
@property (strong, nonatomic)  UILabel *contentLabel;
@property (strong, nonatomic)  UIImageView *contentImage;
@property (strong,nonatomic)   HJModel *model;
@end
