//
//  ViewController.m
//  QingQiuDEMO
//
//  Created by 四川艺匠天诚科技有限公司 on 16/7/18.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import "ViewController.h"
#import "HJNetHelper.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSDictionary *parameters = @{@"mid":@"1000",@"tel":@"18190984085",@"nick":@"hh",@"gender":@"1",@"pwd":@"123456778",@"ptifo":@"iphone",@"address":@"四川省/成都市/新都区",@"cid":@"100"};
//    [[HJNetHelper shareInstance]postWithURL:@"http://192.168.0.200:5000" headerField:nil parameters:parameters completionBlockHandler:^(NSDictionary *responseDic, NSError *error) {
//        NSLog(@"fffff%@",responseDic);
//    }];
//    
//    [[HJNetHelper shareInstance]getWithURL:@"http://192.168.0.200:5000"headerField:nil parameters:parameters completionBlockHandler:^(NSDictionary *responseDic, NSError *error) {
//        NSLog(@"hhh%@",responseDic);
//    }];
    NSString *url =@"http://192.168.0.200:5000";

      [[HJNetHelper sharedInstance]getWithURLString:url parameters:parameters completionBlockHandler:^(NSDictionary *responseDic, NSError *error) {
          NSLog(@"ffff%@",responseDic);
      }];
    [[HJNetHelper sharedInstance]postWithURLString:url parameters:parameters completionBlockHandler:^(NSDictionary *responseDic, NSError *error) {
        NSLog(@"kkkkk%@",responseDic);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
