//
//  HJNetHelper.h
//  数据请求
//
//  Created by 四川艺匠天诚科技有限公司 on 16/7/18.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HJNetHelper.h"

@interface UploadParam : NSObject

//  图片的二进制数据
@property (nonatomic, strong) NSData *data;

 //服务器对应的参数名称

@property (nonatomic, copy) NSString *name;

// 文件的名称(上传到服务器后，服务器保存的文件名)

@property (nonatomic, copy) NSString *filename;

//文件的MIME类型(image/png,image/jpg等)

@property (nonatomic, copy) NSString *mimeType;

@end


typedef NS_ENUM(NSUInteger,HttpRequestType) {

    HttpRequestTypeGet = 0,

    HttpRequestTypePost
};

@interface HJNetHelper : NSObject

+ (instancetype)sharedInstance;

//get请求
- (void)getWithURLString:(NSString *)URLString
              parameters:(NSDictionary *)parameters
  completionBlockHandler:(void(^)(NSDictionary *responseDic, NSError *error)) completionBlock;


//post请求
- (void)postWithURLString:(NSString *)URLString
               parameters:(id)parameters
   completionBlockHandler:(void(^)(NSDictionary *responseDic, NSError *error)) completionBlock;


// 发送网络请求

- (void)requestWithURLString:(NSString *)URLString
                  parameters:(id)parameters
                        type:(HttpRequestType)type
                     success:(void (^)(id responseObject))success
                     failure:(void (^)(NSError *error))failure;

//上传图片
//uploadParam 上传图片的信息
- (void)uploadWithURLString:(NSString *)URLString
                 parameters:(id)parameters
                uploadParam:(UploadParam *)UploadParam
                    success:(void (^)())success
                    failure:(void (^)(NSError *error))failure;

//  下载数据
 - (void)downLoadWithURLString:(NSString *)URLString
                   parameters:(id)parameters
                     progerss:(void (^)())progress
                      success:(void (^)())success
                      failure:(void (^)(NSError *error))failure;

@end
