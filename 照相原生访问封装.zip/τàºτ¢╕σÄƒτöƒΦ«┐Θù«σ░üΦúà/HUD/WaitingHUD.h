//
//  WaitingHUD.h
//  QuHuWai
//
//  Created by wzkj on 15/3/24.
//  Copyright (c) 2015年 Wzkj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WaitingHUD : UIView
@property(nonatomic,copy) NSString *message;
@property(nonatomic,retain) UIImage *userImage;
@property(nonatomic) CGFloat yoffset;
- (void)startAnimation;
- (void)stopAnimation;
+(WaitingHUD *)topHUDInView:(UIView *)view;
+ (void)showHUD:(NSString *)message InView:(UIView *) view;
+ (void)dismissHUDWithImage:(UIImage *)img
                    Message:(NSString *)message
                      Delay:(float)delay
                     InView:(UIView *) view;
+(void)dismissHUDWithSuccess:(NSString *)message InView:(UIView *) view;
+(void)dismissHUDWithError:(NSString *)message InView:(UIView *) view;
+(void)dismissHUDWithInfo:(NSString *)message InView:(UIView *) view;
+(void)dismissHUDInView:(UIView *) view;



+(void)showToastImage:(UIImage*)img Message:(NSString *)msg;
+(void)showToastSuccess:(NSString *)msg;
+(void)showToastError:(NSString *)msg;
+(void)showToastInfo:(NSString *)msg;
@end
