//
//  WaitingHUD.m
//  QuHuWai
//
//  Created by wzkj on 15/3/24.
//  Copyright (c) 2015年 Wzkj. All rights reserved.
//

#import "WaitingHUD.h"
#import "HYCircleLoadingView.h"
#import <objc/runtime.h>
static char hudKey;
@implementation WaitingHUD
{
    
    __weak IBOutlet NSLayoutConstraint *con_image_yoffset;
    __weak IBOutlet NSLayoutConstraint *con_yoffset;
    __weak IBOutlet UILabel *lb_title;
    __weak IBOutlet UIImageView *view_progress;
    UIActivityIndicatorView *loadingView;
}

-(id)initWithFrame:(CGRect) frame
{
    self=[super initWithFrame:frame];
    if (self) {
        NSArray *arr=[[NSBundle mainBundle] loadNibNamed:@"WaitingHUD" owner:self options:nil];
        self=[arr firstObject];
        loadingView=[[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0, 0, view_progress.frame.size.width, view_progress.frame.size.height)];
        loadingView.activityIndicatorViewStyle=UIActivityIndicatorViewStyleWhiteLarge;
        loadingView.color=[UIColor lightGrayColor];
        [view_progress addSubview:loadingView];
        self.frame=frame;
    }
    return self;
}
- (void)startAnimation{
    [loadingView startAnimating];
}
- (void)stopAnimation{
    [loadingView stopAnimating];
}
-(void)setMessage:(NSString *)message
{
    _message=message;
    lb_title.text=[message copy];
    
    if (!_userImage && !loadingView.isAnimating) {
        con_image_yoffset.constant=50;
    }else{
        if (_message && ![@"" isEqualToString:_message]) {
            con_image_yoffset.constant=10;
        }else{
            con_image_yoffset.constant=0;
        }
    }
}
-(void)setUserImage:(UIImage *)userImage
{
    _userImage=userImage;
    view_progress.image=_userImage;
    
    if (!_userImage && !loadingView.isAnimating) {
        con_image_yoffset.constant=50;
    }else{
        if (_message) {
            con_image_yoffset.constant=10;
        }else{
            con_image_yoffset.constant=0;
        }
    }
}
-(void)setYoffset:(CGFloat)yoffset
{
    con_yoffset.constant=yoffset;
}

+ (void)showHUD:(NSString *)message InView:(UIView *) view{
    [WaitingHUD dismissHUDInView:view];
    WaitingHUD *hud=[[WaitingHUD alloc] initWithFrame:CGRectZero];
    [view addSubview:hud];
    [view endEditing:true];
    objc_setAssociatedObject(view,&hudKey,hud,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
    CGRect rect;
    if (view.superview ) {
        rect=[view.superview convertRect:view.frame
                                         toView:[[UIApplication sharedApplication].windows lastObject]];
    }else{
        rect=view.frame;
    }
    
    
    hud.translatesAutoresizingMaskIntoConstraints=NO;
    [view addConstraints:[NSLayoutConstraint
                          constraintsWithVisualFormat:@"H:|[hud]|"
                          options:0
                          metrics:nil
                          views:NSDictionaryOfVariableBindings(hud)]];
    [view addConstraints:[NSLayoutConstraint
                          constraintsWithVisualFormat:[NSString stringWithFormat:@"V:|-(%.1f)-[hud]|",64-rect.origin.y]
                          options:0
                          metrics:nil
                          views:NSDictionaryOfVariableBindings(hud)]];
    
    hud.yoffset=32;
    [hud startAnimation];
    hud.message=message;
    
    ((UIView *)[hud.subviews firstObject]).alpha=0;
    //hud.backgroundColor=[UIColor clearColor];
    [UIView animateWithDuration:0.3 animations:^{
        ((UIView *)[hud.subviews firstObject]).alpha=1.0;
        //hud.backgroundColor=[UIColor colorWithWhite:0 alpha:0.4];
    }];
}
+ (void)dismissHUDWithImage:(UIImage *)img
                    Message:(NSString *)message
                      Delay:(float)delay
                     InView:(UIView *) view{
    WaitingHUD *hud=objc_getAssociatedObject(view, &hudKey);
    if (hud) {
        objc_setAssociatedObject(view,&hudKey,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        hud.userInteractionEnabled=false;
        if (message) {
            hud.message=message;
        }
        if (img) {
            hud.userImage=img;
            [hud stopAnimation];
        }
        [UIView animateWithDuration:0.3
                              delay:delay
                            options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
                             ((UIView *)[hud.subviews firstObject]).alpha=0;
                             //hud.backgroundColor=[UIColor clearColor];
                         } completion:^(BOOL finished) {
                             if (hud.superview) {
                                 [hud removeFromSuperview];
                             }
                         }];
    }
    
}

+(void)dismissHUDWithError:(NSString *)message InView:(UIView *) view{
    [self dismissHUDWithImage:[UIImage imageNamed:@"hud_error"] Message:message Delay:1.0 InView:view];
}
+(void)dismissHUDWithInfo:(NSString *)message InView:(UIView *) view{
     [self dismissHUDWithImage:[UIImage imageNamed:@"hud_info"] Message:message Delay:1.0 InView:view];
}
+(void)dismissHUDWithSuccess:(NSString *)message InView:(UIView *) view{
    [self dismissHUDWithImage:[UIImage imageNamed:@"hud_success"] Message:message Delay:1.0 InView:view];
}
+(void)dismissHUDInView:(UIView *) view{
    [self dismissHUDWithImage:nil Message:nil Delay:0.3 InView:view];
}
+ (void)showHUD:(NSString *)message{
    [WaitingHUD showHUD:message InView:[[UIApplication sharedApplication].windows lastObject]];
}

+(void)dismissHUDWithSuccess:(NSString *)message{
    [self dismissHUDWithImage:[UIImage imageNamed:@"hud_success"]
                      Message:message
                        Delay:1.0
                       InView:[[UIApplication sharedApplication].windows lastObject]];
}

+(void)dismissHUDWithError:(NSString *)message{
    [WaitingHUD dismissHUDWithError:message InView:[[UIApplication sharedApplication].windows lastObject]];
}
+(void)dismissHUD{
    [WaitingHUD dismissHUDInView:[[UIApplication sharedApplication].windows lastObject]];
}

+(void)showToastImage:(UIImage*)img Message:(NSString *)message{
    UIView *view=[[UIApplication sharedApplication].windows lastObject];
    WaitingHUD *hud=[[WaitingHUD alloc] initWithFrame:CGRectMake(0, 0, view.frame.size.width, view.frame.size.height)];
    [view addSubview:hud];
    hud.message=message;
    hud.userImage=img;

    hud.userInteractionEnabled=false;
    ((UIView *)[hud.subviews firstObject]).alpha=0;
    [UIView animateWithDuration:0.3 animations:^{
        ((UIView *)[hud.subviews firstObject]).alpha=1.0;
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.3
                              delay:1.0
                            options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
                             ((UIView *)[hud.subviews firstObject]).alpha=0;
                         } completion:^(BOOL finished) {
                             [hud removeFromSuperview];
                         }];
    }];
}
+(void)showToastSuccess:(NSString *)msg{
    [WaitingHUD showToastImage:[UIImage imageNamed:@"hud_success"] Message:msg];
}
+(void)showToastError:(NSString *)msg{
    [WaitingHUD showToastImage:[UIImage imageNamed:@"hud_error"] Message:msg];
}

+(void)showToastInfo:(NSString *)msg{
    [WaitingHUD showToastImage:[UIImage imageNamed:@"hud_info"] Message:msg];
}

+(WaitingHUD *)topHUDInView:(UIView *)view{
    WaitingHUD *hud=objc_getAssociatedObject(view, &hudKey);
    return hud;
}












@end
