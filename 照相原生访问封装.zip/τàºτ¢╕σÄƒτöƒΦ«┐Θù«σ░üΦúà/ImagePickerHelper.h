//
//  ImagePickerHelper.h
//  G平台
//
//  Created by boyo on 16/4/26.
//  Copyright © 2016年 boyo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
typedef void (^ImagePickerHelper_block)(UIImage *image);

@interface ImagePickerHelper : NSObject<UINavigationControllerDelegate, UIImagePickerControllerDelegate>
+(instancetype) Instance;
-(void) pickSingleImage:(BOOL)allowsEditing
               complete:(ImagePickerHelper_block)block;
-(void) takePhoto:(BOOL)allowsEditing
         complete:(ImagePickerHelper_block)block;
@end
