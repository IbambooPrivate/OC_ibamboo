//
//  ImagePickerHelper.m
//  G平台
//
//  Created by boyo on 16/4/26.
//  Copyright © 2016年 boyo. All rights reserved.
//

#import "ImagePickerHelper.h"
#import "WaitingHUD.h"
static ImagePickerHelper *ImagePickerHelper_instance=nil;
@implementation ImagePickerHelper
{
    UIViewController *rootViewController;
    ImagePickerHelper_block block;
}
-(id)init
{
    self=[super init];
    if (self) {
        rootViewController=[[UIApplication sharedApplication].delegate window].rootViewController;
    }
    return self;
}
+(instancetype) Instance{
    if(!ImagePickerHelper_instance){
        ImagePickerHelper_instance=[[ImagePickerHelper alloc] init];
    }
    return ImagePickerHelper_instance;
}

-(void) pickSingleImage:(BOOL)allowsEditing
               complete:(ImagePickerHelper_block)_block{
    block=_block;
    [self localPhoto:allowsEditing];
}
-(void) takePhoto:(BOOL)allowsEditing
         complete:(ImagePickerHelper_block)_block{
    block=_block;
    [self takePhoto:allowsEditing];
}

//开始拍照

-(void)takePhoto:(BOOL) allowsEditing
{
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        //设置拍照后的图片可被编辑
        picker.allowsEditing = allowsEditing;
        picker.sourceType = sourceType;
        picker.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
        [rootViewController presentViewController:picker animated:YES completion:nil];
    }else
    {
        [WaitingHUD showToastInfo:@"无法打开照相机!"];
        block=nil;
    }
}
//打开本地相册
-(void)localPhoto:(BOOL) allowsEditing
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    //设置选择后的图片可被编辑
    picker.allowsEditing = allowsEditing;
    picker.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    [rootViewController presentViewController:picker animated:NO completion:nil];
}
//当选择一张图片后进入这里
-(void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary *)info

{
    NSString *type = [info objectForKey:UIImagePickerControllerMediaType];
    //当选择的类型是图片
    if ([type isEqualToString:@"public.image"])
    {
        //关闭相册界面
        [picker dismissViewControllerAnimated:YES completion:nil];
        UIImage* image = [info objectForKey:picker.allowsEditing?
                            UIImagePickerControllerEditedImage:
                            UIImagePickerControllerOriginalImage];
        if (block) {
            block(image);
            block=nil;
        }
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"您取消了选择图片");
    block=nil;
    [picker dismissViewControllerAnimated:YES completion:nil];
}
@end
