//
//  TableViewCell.m
//  AutoCellHeight
//
//  Created by mac1 on 16/6/23.
//  Copyright © 2016年 BNDK. All rights reserved.
//

#import "TableViewCell.h"

@interface TableViewCell ()

@property (weak, nonatomic) UILabel     *label;
@property (strong, nonatomic) UIImageView *imageV;

@end

@implementation TableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(20, 10, 300, 0)];
        label.numberOfLines = 0;
        label.font = [UIFont systemFontOfSize:15];
        label.textColor = [UIColor redColor];
        [self.contentView addSubview:label];
        _label = label;
        
        _imageV = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"1.jpg"]];
        [self.contentView addSubview:_imageV];
        
    }
    
    return self;
}

- (void)setupCellWithString:(NSString *)str withIndex:(NSInteger)index
{
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc] initWithString:str];
    NSMutableParagraphStyle * paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:10];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [str length])];
    
    
    _label.attributedText = attributedString;
    [_label sizeToFit];
    
    _imageV.frame = CGRectMake(20, CGRectGetMaxY(_label.frame), 80*index , 80*index);
    
    
}

- (CGFloat)getRowHeightWithStr:(NSString *)str withIndex:(NSInteger)index
{
    // 这里需要重新设置一下Label
    [self setupCellWithString:str withIndex:index];
    
    //返回label 的最大Y值
    return  CGRectGetMaxY(_label.frame)+CGRectGetHeight(_imageV.frame) + 11;
}


@end
