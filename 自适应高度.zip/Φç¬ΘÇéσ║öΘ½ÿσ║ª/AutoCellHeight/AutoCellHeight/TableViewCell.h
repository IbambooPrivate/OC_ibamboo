//
//  TableViewCell.h
//  AutoCellHeight
//
//  Created by mac1 on 16/6/23.
//  Copyright © 2016年 BNDK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell


- (void)setupCellWithString:(NSString *)str withIndex:(NSInteger)index;

- (CGFloat)getRowHeightWithStr:(NSString *)str withIndex:(NSInteger)index;
@end
