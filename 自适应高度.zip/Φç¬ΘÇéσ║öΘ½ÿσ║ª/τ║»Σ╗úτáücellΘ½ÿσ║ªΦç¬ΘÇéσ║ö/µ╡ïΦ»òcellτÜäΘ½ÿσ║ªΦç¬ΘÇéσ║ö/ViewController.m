//
//  ViewController.m
//  测试cell的高度自适应
//
//  Created by stone on 16/6/5.
//  Copyright © 2016年 zm. All rights reserved.
//

#import "ViewController.h"
#import "Model.h"
#import "MyTableViewCell.h"
#import "ZmImageView.h"
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITableView* tableView;
@property (nonatomic,strong)NSMutableArray* dataArr;
@end

@implementation ViewController
-(NSMutableArray *)dataArr
{
    if (_dataArr == nil) {
        _dataArr = [[NSMutableArray alloc]init];
        Model* model1 = [Model new];
        model1.title = @"胖虎";
        model1.content = @"我是胖虎我怕谁!我是胖虎我怕谁!我我是胖虎我怕谁!我是胖虎我怕谁!我是胖虎我怕谁!是胖虎我怕谁!";
        model1.iconPath = [[NSBundle mainBundle]pathForResource:@"11" ofType:@"jpg"];
        model1.image1 = [UIImage imageNamed:@"22.jpg"];
        model1.image2 = [UIImage imageNamed:@"44.jpg"];
        Model* model2 = [Model new];
        model2.title = @"多啦A梦";
        model2.content = @"我是多啦A梦我我是多啦A梦我我是多啦A梦我我是多啦A梦我我是多啦A梦我我是多啦A梦我我是多啦A梦我我是多啦A梦我我是多啦A梦我我是多啦A梦我我是多啦A梦我我是";
        model2.iconPath =[[NSBundle mainBundle]pathForResource:@"11" ofType:@"jpg"];
        model2.image1 = [UIImage imageNamed:@"2"];
        model2.image2 = [UIImage imageNamed:@"11"];
        model2.image1 = [UIImage imageNamed:@"33.jpg"];
        model2.image2 = [UIImage imageNamed:@"22.jpg"];
        Model* model3 = [Model new];
        model3.title = @"大雄";
        model3.content = @"我是大熊";
        model3.iconPath = [[NSBundle mainBundle]pathForResource:@"11" ofType:@"jpg"];

        [_dataArr addObject:model1];
        [_dataArr addObject:model2];
        [_dataArr addObject:model3];
    }
    return _dataArr;
}



-(UITableView *)tableView
{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
//        _tableView.separatorInset = UIEdgeInsetsMake(0,70, 0, 0);
        _tableView.estimatedRowHeight = 50;
    }
    return _tableView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"测试布局";
    [self.view addSubview:self.tableView];
    self.tableView.tableFooterView = [UIView new];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - UItabelViewDelegate UItableViewDataSource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArr.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString* identifier = @"cell";
    MyTableViewCell* cell = [self.tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {

        cell = [[MyTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    Model* model = [self.dataArr objectAtIndex:indexPath.row];
    cell.titleLb.text = model.title;
    cell.contentLb.text = model.content;
    cell.imageView1.imageView.image = model.image1;
    cell.imageView2.imageView.image = model.image2;
    [cell.iconImageView setImage:[UIImage imageNamed:@"11.jpg"]];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}


- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    cell.separatorInset = UIEdgeInsetsZero;
    cell.layoutMargins = UIEdgeInsetsZero;
    cell.preservesSuperviewLayoutMargins = NO;
}



@end

