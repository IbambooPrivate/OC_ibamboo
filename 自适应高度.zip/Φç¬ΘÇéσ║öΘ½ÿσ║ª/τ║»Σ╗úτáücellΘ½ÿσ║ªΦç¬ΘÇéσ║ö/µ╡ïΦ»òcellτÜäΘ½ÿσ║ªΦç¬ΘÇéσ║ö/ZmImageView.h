//
//  ZmImageView.h
//  BaseProject
//
//  Created by stone on 16/6/1.
//  Copyright © 2016年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZmImageView : UIView
@property (nonatomic,strong)UIImageView* imageView;



@end
