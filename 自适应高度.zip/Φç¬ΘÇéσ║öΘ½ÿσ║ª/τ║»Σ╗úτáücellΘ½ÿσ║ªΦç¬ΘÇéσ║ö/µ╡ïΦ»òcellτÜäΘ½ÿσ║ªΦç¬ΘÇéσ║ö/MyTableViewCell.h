//
//  MyTableViewCell.h
//  测试cell的高度自适应
//
//  Created by stone on 16/6/5.
//  Copyright © 2016年 zm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZmImageView.h"
@interface MyTableViewCell : UITableViewCell

@property (nonatomic,strong)UILabel* titleLb;
@property (nonatomic,strong)UILabel* contentLb;
@property (nonatomic,strong)UIImageView* iconImageView;
@property (nonatomic,strong)ZmImageView* imageView1;
@property (nonatomic,strong)ZmImageView* imageView2;
@property (nonatomic,strong)UIView* showPhotoView;

@end
