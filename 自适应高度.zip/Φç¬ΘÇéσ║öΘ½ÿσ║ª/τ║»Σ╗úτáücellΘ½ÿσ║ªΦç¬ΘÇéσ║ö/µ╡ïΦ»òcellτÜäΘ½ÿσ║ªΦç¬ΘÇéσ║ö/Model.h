//
//  Model.h
//  测试cell的高度自适应
//
//  Created by stone on 16/6/5.
//  Copyright © 2016年 zm. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface Model : NSObject
@property (nonatomic,strong)NSString* title;
@property (nonatomic,strong)NSString* content;
@property (nonatomic,strong)NSString* iconPath;
@property (nonatomic,strong)UIImage* image1;
@property (nonatomic,strong)UIImage* image2;
@end
