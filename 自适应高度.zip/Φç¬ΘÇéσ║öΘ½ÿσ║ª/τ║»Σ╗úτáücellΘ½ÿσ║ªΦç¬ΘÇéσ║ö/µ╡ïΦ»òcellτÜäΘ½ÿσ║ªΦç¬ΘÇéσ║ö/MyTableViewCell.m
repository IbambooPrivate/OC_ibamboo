//
//  MyTableViewCell.m
//  测试cell的高度自适应
//
//  Created by stone on 16/6/5.
//  Copyright © 2016年 zm. All rights reserved.
//

#import "MyTableViewCell.h"
#import "Masonry.h"
#import "Model.h"
@implementation MyTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
}


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self initLayuot];
//        self.backgroundColor = [UIColor blueColor];
        self.selectionStyle = UITableViewCellSelectionStyleDefault;
//        UIColor *color = [UIColor redColor];//通过RGB来定义自己的颜色
        self.selectedBackgroundView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"44.jpg"]];
//        self.selectedBackgroundView.backgroundColor = color;
    }
    return self;
}

-(void)initLayuot{
    self.titleLb = [UILabel new];
    self.titleLb.backgroundColor = [UIColor grayColor];
    self.contentLb = [UILabel new];
    self.contentLb.numberOfLines = 0;
    self.contentLb.font = [UIFont systemFontOfSize:14];
    self.iconImageView = [UIImageView new];
    self.imageView1 = [ZmImageView new];
    self.imageView2 = [ZmImageView new];
    self.imageView1.contentMode = UIViewContentModeScaleAspectFill;
    self.imageView2.contentMode = UIViewContentModeScaleAspectFill;
    [self.contentView addSubview:_contentLb];
    [self.contentView addSubview:_iconImageView];
    [self.contentView addSubview:_titleLb];
    [self.contentView addSubview:_imageView1];
    [self.contentView addSubview:_imageView2];
    [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(50, 50));
        make.top.left.mas_equalTo(10);
    }];
    [self.titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.topMargin.mas_equalTo(self.iconImageView.mas_topMargin);
        make.left.mas_equalTo(self.iconImageView.mas_right).mas_equalTo(10);
        make.height.mas_equalTo(30);
    }];
    [self.contentView addSubview:_contentLb];
    _contentLb.backgroundColor = [UIColor yellowColor];
    [self.contentLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leftMargin.mas_equalTo(self.titleLb.mas_leftMargin );
        make.right.mas_lessThanOrEqualTo(-20);
        make.top.mas_equalTo(self.titleLb.mas_bottom).mas_equalTo(10);
        make.bottom.mas_equalTo(self.imageView1.mas_top).mas_equalTo(-10);
        make.height.mas_greaterThanOrEqualTo(3);
    }];
    [self.imageView1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_greaterThanOrEqualTo(0);
        make.height.mas_lessThanOrEqualTo(100);
        make.left.mas_equalTo(10);
        make.right.mas_equalTo(self.imageView2.mas_left).mas_equalTo(-10);
        make.bottom.mas_equalTo(-10);
    }];
    [self.imageView2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(self.imageView1);
        make.right.mas_equalTo(-10);
        make.bottomMargin.mas_equalTo(self.imageView1.mas_bottomMargin);
    }];


}



@end
