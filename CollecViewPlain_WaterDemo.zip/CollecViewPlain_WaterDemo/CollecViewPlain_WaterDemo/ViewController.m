//
//  ViewController.m
//  CollecViewPlain_WaterDemo
//
//  Created by 四川艺匠天诚科技有限公司 on 16/11/11.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import "ViewController.h"
#import "SYStickHeaderWaterFallLayout.h"
#import "CollectionViewCell.h"
#import "HeaderCollectionReusableView.h"
#define kDeviceWidth  [UIScreen mainScreen].bounds.size.width
#define kDeviceHeight [UIScreen mainScreen].bounds.size.height
#define  WIGTH SCREEN_WIDTH/3.f
#define  HEIGHT [[UIScreen mainScreen] bounds].size.height/667*41


@interface ViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UIScrollViewDelegate,SYStickHeaderWaterFallDelegate>

@property (nonatomic, strong) UICollectionView *collectView;

@property (nonatomic, strong) UIButton *salingBtn;

@property (nonatomic, strong) UIButton *willSaleBtn;

@property (nonatomic, strong) UIButton *previewBtn;

@property (nonatomic, strong) UIView *lineView;

@end

@implementation ViewController{
    UICollectionReusableView *reusableView;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    SYStickHeaderWaterFallLayout *cvLayout = [[SYStickHeaderWaterFallLayout alloc] init];
    cvLayout.delegate = self;
    cvLayout.isStickyHeader = YES;
    
    self.collectView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, kDeviceWidth, kDeviceHeight ) collectionViewLayout:cvLayout];
    [self.view addSubview:self.collectView];
     self.collectView.backgroundColor = [UIColor whiteColor];

    
    
    [self.collectView registerNib:[UINib nibWithNibName:@"CollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"Waterfall"];
    
    [self.collectView registerNib:[UINib nibWithNibName:@"HeaderCollectionReusableView" bundle:nil] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"header"];
    
    self.collectView.delegate =self;
    self.collectView.dataSource =self;
    
}
#pragma mark -- 区数
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    [collectionView.collectionViewLayout invalidateLayout];
    return 3;
}

#pragma mark -- item个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 20;
}

#pragma mark -- 区头
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    reusableView = nil;
    if ([kind isEqual:UICollectionElementKindSectionHeader]) {
        HeaderCollectionReusableView *headView= (HeaderCollectionReusableView *)[collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"header" forIndexPath:indexPath];
        headView.tag = 1001 +indexPath.section;
        reusableView = headView;
        _lineView = [[UIView alloc]init];
  
        return reusableView;
    }
    
    return nil;
    
}

#pragma mark -- item
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Waterfall" forIndexPath:indexPath];
    
    return cell;
    
}
#pragma mark -- 点击item
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
}


#pragma mark --  返回所在section的每个item的width（一个section只有一个width）
- (CGFloat)collectionView:(nonnull UICollectionView *)collectionView
                   layout:(nonnull SYStickHeaderWaterFallLayout *)collectionViewLayout
    widthForItemInSection:( NSInteger )section{
    return (kDeviceWidth - 30)/2.f;
}
#pragma mark --  返回所在indexPath的每个item的height（每个item有一个height）
- (CGFloat)collectionView:(nonnull UICollectionView *)collectionView
                   layout:(nonnull SYStickHeaderWaterFallLayout *)collectionViewLayout
 heightForItemAtIndexPath:(nonnull NSIndexPath *)indexPath{
    switch (indexPath.item%5) {
        case 0:
            return 30;
            break;
            
        case 1:
            return 70;
            break;
        case 2:
            return 300;
            break;

        case 3:
            return 180;
            break;
        case 4:
            return 50;
            break;

        default:
            break;
    }
    return 0;
}

#pragma mark --  返回所在indexPath的header的height
- (CGFloat) collectionView:(nonnull UICollectionView *)collectionView
                    layout:(nonnull SYStickHeaderWaterFallLayout *)collectionViewLayout
heightForHeaderAtIndexPath:(nonnull NSIndexPath *)indexPath{
    return 50;
}
#pragma mark -- 返回所在indexPath的footer的height
- (CGFloat) collectionView:(nonnull UICollectionView *)collectionView
                    layout:(nonnull SYStickHeaderWaterFallLayout *)collectionViewLayout
heightForFooterAtIndexPath:(nonnull NSIndexPath *)indexPath{
    return 0;
}
#pragma mark --  返回所在section与上一个section的间距
- (CGFloat) collectionView:(nonnull UICollectionView *)collectionView
                    layout:(nonnull SYStickHeaderWaterFallLayout *)collectionViewLayout
              topInSection:(NSInteger )section{
    return 0;
}
#pragma mark --  返回所在section与下一个section的间距
- (CGFloat) collectionView:(nonnull UICollectionView *)collectionView
                    layout:(nonnull SYStickHeaderWaterFallLayout *)collectionViewLayout
           bottomInSection:( NSInteger)section{
    return 0;
}
#pragma mark --  返回所在section的header停留时与顶部的距离（如果设置isTopForHeader ＝ yes ，则距离会叠加）

- (CGFloat) collectionView:(nonnull UICollectionView *)collectionView
                    layout:(nonnull SYStickHeaderWaterFallLayout *)collectionViewLayout
      headerToTopInSection:( NSInteger)section{
    return 0;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
