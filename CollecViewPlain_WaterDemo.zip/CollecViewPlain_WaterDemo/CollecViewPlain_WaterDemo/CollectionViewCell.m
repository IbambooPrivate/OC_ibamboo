//
//  CollectionViewCell.m
//  CollecViewPlain_WaterDemo
//
//  Created by 四川艺匠天诚科技有限公司 on 16/11/11.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
