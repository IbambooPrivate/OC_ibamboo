//
//  View_Cartogram_Block.m
//  LSGS
//
//  Created by wzkj_macmini on 15/8/18.
//  Copyright (c) 2015年 wzkj_macmini. All rights reserved.
//

#import "View_Cartogram.h"
#import "UIColor+expanded.h"
#import <math.h>
#define AXIS_WIDTH 2.0
//相邻方块的距离 BLOCK_GAP
#define BLOCK_GAP  0.0
#define MARK_OFFSET 2
#define TEXT_OFFSET 2
@implementation CartogramData
-(void)setValue:(CGFloat)value{
    if (value>1) {
        value=1;
    }
    if (value<0) {
        value=0;
    }
    _value=value;
}
@end



@interface View_Cartogram()

@property(nonatomic,readonly) CGFloat canvasHeight;
@property(nonatomic,readonly) CGFloat canvasWidth;
@property(nonatomic,readonly) CGFloat topOffset;
@property(nonatomic,readonly) CGFloat rightMargin;
@property(nonatomic,readonly) CGFloat bottomMargin;
@property(nonatomic,readonly) CGFloat topMargin;
@property(nonatomic,readonly) CGFloat leftMargin;
@end

@implementation View_Cartogram
{
    CGFloat block_width;
    CGFloat column_gap;
    
    UIScrollView *scroll;
    UIImageView *imageView;
    UIImage *contentImage;
    
}
-(CGFloat)canvasHeight{
    return self.bounds.size.height-self.topOffset-self.topMargin-AXIS_WIDTH-self.bottomMargin;
}
-(CGFloat)canvasWidth{
    return self.bounds.size.width-3*AXIS_WIDTH-self.leftMargin-self.rightMargin;
}
-(CGFloat)topOffset{
    return _textFont.lineHeight+2*TEXT_OFFSET;
}
-(CGFloat) rightMargin{
    CGSize size=[_horizontalTitle sizeWithFont:_textFont];
    if (size.width==0) {
        return 0;
    }
    return size.width+2*TEXT_OFFSET;
}
-(CGFloat) bottomMargin{
    return 4+_textFont.lineHeight+2*TEXT_OFFSET;
}
-(CGFloat)topMargin{
    return _markFont.lineHeight+2*MARK_OFFSET+(_type==Type_Line?(_dotWidth+4)/2:0);
}
-(CGFloat)leftMargin{
    CGSize size=CGSizeZero;
    for (CartogramData *obj in _levelLines) {
        CGSize new=[obj.text sizeWithFont:_textFont];
        if (new.width>size.width) {
            size=new;
        }
    }
    CGSize new=[_verticalTitle sizeWithFont:_textFont];
    if (new.width/2>size.width+TEXT_OFFSET) {
        size.width=new.width/2-TEXT_OFFSET;
    }
    if (size.width==0) {
        return 0;
    }
    return size.width+2*TEXT_OFFSET;
}

-(void)setTextColor:(UIColor *)textColor{
    _textColor=textColor;
    contentImage=nil;
    [self setNeedsDisplay];
}
-(void)setTextFont:(UIFont *)textFont{
    _textFont=textFont;
    contentImage=nil;
    [self setNeedsDisplay];
}

-(void)setLevelLines:(NSMutableArray *)levelLines{
    _levelLines=levelLines;
    [self setNeedsDisplay];
}
-(void)setMaxBlockCount:(NSInteger)maxBlockCount{
    _maxBlockCount=maxBlockCount;
    [self setNeedsDisplay];
}
-(void)setVerticalTitle:(NSString *)verticalTitle{
    _verticalTitle=verticalTitle;
    [self setNeedsDisplay];
}
-(void)setHorizontalTitle:(NSString *)horizontalTitle{
    _horizontalTitle=horizontalTitle;
    [self setNeedsDisplay];
}
-(void)setType:(int)type{
    _type=type;
    contentImage=nil;
    [self setNeedsDisplay];
}
-(void)setContentOffset:(CGFloat)contentOffset{
    [scroll setContentOffset:CGPointMake(contentOffset, 0)];
    [self setNeedsDisplay];
}
-(CGFloat)contentOffset{
    return scroll.contentOffset.x;
}

- (void)setBottomMargin:(CGFloat)bottomMargin
{
    if (bottomMargin < 15) {
        bottomMargin = 15;
    }
    self.bottomMargin = bottomMargin;
    [self setNeedsDisplay];
}

-(void)initValueWithRect:(CGRect) rect
{
    if (_dataArr.count==0 || CGRectEqualToRect(rect, CGRectZero)) {
        return;
    }
    //小方块的宽度
    //CGFloat block_width_tmp = self.canvasHeight/(_maxBlockCount)-BLOCK_GAP;
    CGFloat block_width_tmp = 65;
    CGFloat canvasWidth=self.canvasWidth;
    CGFloat column_gap_tmp=canvasWidth/_dataArr.count-block_width_tmp;
    if (column_gap_tmp<block_width_tmp) {
        column_gap_tmp=block_width_tmp;
    }
    CGFloat contentWidth=(column_gap_tmp+block_width_tmp)*_dataArr.count;
    
    if (column_gap_tmp!=column_gap || block_width_tmp!=block_width || contentWidth!=_contentWidth) {
        column_gap=column_gap_tmp;
        block_width=block_width_tmp;
        contentImage=nil;
    }
    if (contentWidth!=_contentWidth) {
        _contentWidth=contentWidth;
        scroll.frame=CGRectMake(self.leftMargin+2*AXIS_WIDTH, 0, canvasWidth, rect.size.height);
        [scroll setContentSize:CGSizeMake(_contentWidth, rect.size.height)];
        [scroll setContentOffset:CGPointMake(_contentWidth-scroll.frame.size.width, 0)];
        imageView.frame=CGRectMake(0, 0, _contentWidth, rect.size.height);
    }
}
- (void)setDataArr:(NSMutableArray *)dataArr
{
    _dataArr = dataArr;
    [self setNeedsDisplay];
}
-(void)setBlockColor:(UIColor *)blockColor
{
    _blockColor=blockColor;
    contentImage=nil;
    [self setNeedsDisplay];
}
-(void)setAxisColor:(UIColor *)axisColor{
    _axisColor=axisColor;
    [self setNeedsDisplay];
}
-(void)setRightMargin:(CGFloat)rightMargin{
    self.rightMargin=rightMargin;
    [self setNeedsDisplay];
}
-(void)setMarkColor:(UIColor *)markColor{
    _markColor=markColor;
    contentImage=nil;
    [self setNeedsDisplay];
}
-(void)setMarkFont:(UIFont *)markFont{
    _markFont=markFont;
    [self setNeedsDisplay];
}
-(void)setLevelLineColor:(UIColor *)levelLineColor{
    _levelLineColor=levelLineColor;
    [self setNeedsDisplay];
}
- (void)setShadowHeight:(CGFloat)shadowHeight
{
    if (shadowHeight < 0) {
        shadowHeight = 0;
    }
    _shadowHeight = shadowHeight;
    [self setNeedsDisplay];
}
-(instancetype)initWithFrame:(CGRect)frame{
    self=[super initWithFrame:frame];
    if (self) {
        [self setupUI];
    }
    return self;
}
-(instancetype)initWithCoder:(NSCoder *)aDecoder{
    self=[super initWithCoder:aDecoder];
    if (self) {
        [self setupUI];
    }
    return self;
}
- (void)setupUI
{
    self.backgroundColor=[UIColor clearColor];
    _shadowHeight=30.0;
    _maxBlockCount = 12;    // 默认块数为12块
    _dotWidth = 4;
    _axisColor=[UIColor blueColor];
    _blockColor=[UIColor blueColor];
    _markColor = [UIColor blueColor];
    _markFont = [UIFont systemFontOfSize:12];
    _levelLineColor=[UIColor blueColor];
    _verticalTitle = @"垂直";
    _horizontalTitle = @"水平";
    _textColor = [UIColor blueColor];
    _textFont = [UIFont boldSystemFontOfSize:14];
    self.clipsToBounds=true;
    
    scroll=[[UIScrollView alloc] init];
    scroll.backgroundColor=[UIColor clearColor];
    [self addSubview:scroll];
    imageView=[[UIImageView alloc] init];
    [scroll addSubview:imageView];
    
    _dataArr=[NSMutableArray array];
    int dataCnt=1+arc4random()%30;//1到30直接的随机数
    for (int i=1; i<=dataCnt; i++) {
        CartogramData *data=[CartogramData new];
        data.value=(1+(arc4random()%100))/100.0;
        data.text=[NSString stringWithFormat:@"%d",i];
        data.mark=[NSString stringWithFormat:@"%.2f",_maxBlockCount*data.value];
        [_dataArr addObject:data];
    }
    
    _levelLines=[NSMutableArray array];
    int lineCnt=1+arc4random()%_maxBlockCount;
    for (int i=0; i<lineCnt; i++) {
        CartogramData *data=[CartogramData new];
        data.value=(float)i/lineCnt;
        data.text=[NSString stringWithFormat:@"%.0f",_maxBlockCount*data.value];
        [_levelLines addObject:data];
    }
}

-(void)setBounds:(CGRect)bounds
{
    [super setBounds:bounds];
    [self setNeedsDisplay];
}


#pragma mark - 绘图
- (void)drawRect:(CGRect)rect
{
    //[super drawRect:rect];
    CGContextRef context = UIGraphicsGetCurrentContext();
    //绘制方块
    [self initValueWithRect:rect];
    CGFloat canvasHeight=self.canvasHeight;
    CGFloat canvasWidth=self.canvasWidth;
    CGFloat topOffset=self.topOffset;
    CGFloat rightMargin=self.rightMargin;
    CGFloat bottomMargin=self.bottomMargin;
    CGFloat topMargin=self.topMargin;
    CGFloat leftMargin=self.leftMargin;
    //底部阴影
    CGContextSetShadowWithColor(context, CGSizeMake(0, -bottomMargin-AXIS_WIDTH-_shadowHeight), _shadowHeight, _axisColor.CGColor);
    CGContextSetStrokeColorWithColor(context, _axisColor.CGColor);
    CGContextBeginPath(context);
    CGContextMoveToPoint(context, leftMargin+AXIS_WIDTH, rect.size.height+_shadowHeight);
    CGContextSetLineWidth(context,_shadowHeight/2);
    CGContextAddLineToPoint(context, rect.size.width-rightMargin, rect.size.height+_shadowHeight);
    CGContextStrokePath(context);
    CGContextSetShadowWithColor(context, CGSizeMake(0, 0), 0, [UIColor clearColor].CGColor);
    CGContextClearRect(context,CGRectMake(leftMargin+2*AXIS_WIDTH,
                                          rect.size.height-bottomMargin-AXIS_WIDTH,
                                          canvasWidth,
                                          bottomMargin+AXIS_WIDTH));
    
    //绘制柱形图
    if (!contentImage) {
        UIGraphicsBeginImageContextWithOptions(CGSizeMake(_contentWidth, rect.size.height),false,[self respondsToSelector:@selector(scale)]);
        context = UIGraphicsGetCurrentContext();
        int i=0;
        CGPoint *points=NULL;
        if (_dataArr.count && _type==Type_Line) {
            points=malloc(_dataArr.count*sizeof(CGPoint));
        }
        //for循环以及下面注释的height是绘制小方块，
        for (CartogramData *obj in _dataArr) {
            CGFloat left_Pos= column_gap/2+(column_gap+block_width)*i;
            CGFloat bottom_Pos=rect.size.height-bottomMargin-AXIS_WIDTH;//下
            CGFloat width=block_width;
            CGFloat height=canvasHeight*obj.value;
            //CGFloat height=canvasHeight;
            switch (_type) {
                case Type_Block:
                {
                    CGContextAddRect(context, CGRectMake(left_Pos, bottom_Pos-height, width, height));
                    CGContextSetFillColorWithColor(context, _blockColor.CGColor);
                    CGContextFillPath(context);
                    for (int j=0; j<(int)(height/(block_width+BLOCK_GAP)); j++) {
                        CGContextClearRect(context,CGRectMake(left_Pos, bottom_Pos-(j+1)*(block_width+BLOCK_GAP), width, BLOCK_GAP));
                    }
                }
                    break;
                case Type_Line:
                {
                    CGPoint pt={left_Pos+block_width/2,bottom_Pos-height};
                    points[i]=pt;
                    CGContextSetFillColorWithColor(context, _blockColor.CGColor);
                    CGContextFillEllipseInRect(context, CGRectMake(pt.x-_dotWidth/2, pt.y-_dotWidth/2, _dotWidth, _dotWidth));
                    CGContextFillPath(context);
                    
                    CGContextSetStrokeColorWithColor(context, _blockColor.CGColor);
                    CGContextSetLineWidth(context, 1);
                    CGContextAddEllipseInRect(context, CGRectMake(pt.x-(_dotWidth+4)/2,pt.y-(_dotWidth+4)/2, (_dotWidth+4), (_dotWidth+4)));
                    CGContextStrokePath(context);
                }
                    break;
                    
                default:
                    break;
            }
            i++;
        }
        if (points) {
            CGContextSetLineJoin(context, kCGLineJoinRound);
            CGContextSetLineCap(context , kCGLineCapRound);
            CGContextSetBlendMode(context, kCGBlendModeNormal);
            CGContextBeginPath(context);
            CGContextAddLines(context,points,_dataArr.count);
            CGContextSetLineWidth(context, AXIS_WIDTH);
            CGContextSetStrokeColorWithColor(context, _blockColor.CGColor);
            CGContextStrokePath(context);
            free(points);
        }
        i=0;
        for (CartogramData *obj in _dataArr) {
            CGFloat left_Pos= column_gap/2+(column_gap+block_width)*i;
            CGFloat bottom_Pos=rect.size.height-bottomMargin-AXIS_WIDTH;//下
            CGFloat height=canvasHeight*obj.value;
            
            [self drawString:obj.mark
                      inRect:CGRectMake((left_Pos-column_gap/2)/2,
                                        bottom_Pos-height-_markFont.lineHeight-MARK_OFFSET-((_type==Type_Line)?(_dotWidth+4)/2:0),
                                        left_Pos+block_width+column_gap/2,
                                        _markFont.lineHeight)
                        font:_markFont
                       color:_markColor
                   alignment:NSTextAlignmentCenter];
            
            [self drawString:obj.text
                      inRect:CGRectMake((left_Pos-column_gap/2)/2,
                                        bottom_Pos+AXIS_WIDTH+TEXT_OFFSET,
                                        left_Pos+block_width+column_gap/2,
                                        _textFont.lineHeight)
                        font:_textFont
                       color:_textColor
                   alignment:NSTextAlignmentCenter];
            i++;
        }
        
        
        contentImage=UIGraphicsGetImageFromCurrentImageContext();
        imageView.image=contentImage;
        UIGraphicsEndImageContext();
    }
    context = UIGraphicsGetCurrentContext();
    //清除溢出区域
    CGContextClearRect(context,CGRectMake(0, 0, leftMargin+2*AXIS_WIDTH, rect.size.height));
    CGContextClearRect(context,CGRectMake(rect.size.width-AXIS_WIDTH-rightMargin, 0, AXIS_WIDTH+rightMargin, rect.size.height));
    
    //X轴
    CGContextSetStrokeColorWithColor(context, _axisColor.CGColor);
    CGContextBeginPath(context);
    CGContextMoveToPoint(context, leftMargin+AXIS_WIDTH, rect.size.height-bottomMargin-AXIS_WIDTH/2);
    CGContextSetLineWidth(context,AXIS_WIDTH);
    CGContextAddLineToPoint(context, rect.size.width-rightMargin, rect.size.height-bottomMargin-AXIS_WIDTH/2);
    CGContextStrokePath(context);
    [self drawString:_horizontalTitle inRect:CGRectMake((rect.size.width-rightMargin),
                                                        rect.size.height-bottomMargin-_textFont.lineHeight/2,
                                                        rightMargin,
                                                        _textFont.lineHeight)
                font:_textFont
               color:_textColor
           alignment:NSTextAlignmentCenter];
    
    
    if (leftMargin) {
        //Y 轴
        CGContextSetStrokeColorWithColor(context, _axisColor.CGColor);
        CGContextBeginPath(context);
        CGContextMoveToPoint(context, leftMargin+AXIS_WIDTH/2, topOffset);
        CGContextSetLineWidth(context,AXIS_WIDTH);
        CGContextAddLineToPoint(context, leftMargin+AXIS_WIDTH/2, rect.size.height-bottomMargin);
        CGContextStrokePath(context);
        
        [self drawString:_verticalTitle
                  inRect:CGRectMake(0, TEXT_OFFSET,
                                    (leftMargin+AXIS_WIDTH)*2, _textFont.lineHeight)
                    font:_textFont
                   color:_textColor
               alignment:NSTextAlignmentCenter];
        
        //虚线
        for (CartogramData *obj in _levelLines) {
            if (obj.value==0) {
                continue;
            }
            //拉通虚线 rect.size.width-rightMargin-AXIS_WIDTH
            //长度为5的虚线  leftMargin+AXIS_WIDTH+5
            CGFloat ypos=topMargin+topOffset+canvasHeight*(1-obj.value);
            [self drawDotLine:context
                   orginPoint:CGPointMake(leftMargin+AXIS_WIDTH,ypos)
                      toPoint:CGPointMake(leftMargin+AXIS_WIDTH+5, ypos)
                        color:_levelLineColor];
            [self drawString:obj.text
                      inRect:CGRectMake(0, ypos-_textFont.lineHeight/2, leftMargin-TEXT_OFFSET, _textFont.lineHeight)
                        font:_textFont
                       color:_textColor
                   alignment:NSTextAlignmentRight];
            
        }
    }
}
- (void) drawString:(NSString *) str
             inRect:(CGRect)rectangle
               font:(UIFont *)font
              color:(UIColor *)color
          alignment:(NSTextAlignment)alignment{ // 设置字体大小以及居中显示
    NSMutableParagraphStyle *style = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    [style setAlignment:alignment];
    // 在这里设置文本大小以及颜色
    NSDictionary *attrsDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                     font, NSFontAttributeName,
                                     [NSNumber numberWithFloat:1.0],NSBaselineOffsetAttributeName,
                                     style,NSParagraphStyleAttributeName,
                                     color,NSForegroundColorAttributeName, nil];
    
    [str drawInRect:rectangle withAttributes:attrsDictionary];
}


// 画虚线
- (void) drawDotLine:(CGContextRef) context orginPoint:(CGPoint) orginPoint toPoint:(CGPoint)toPoint color:(UIColor *) color {
    CGFloat lengths[] = {5,5}; // 先画5个点，再跳过5个点
    CGContextSetStrokeColorWithColor(context, color.CGColor);
    CGContextSetLineWidth(context, 0.5); // 虚线宽度
    CGContextSetLineDash(context, 0, lengths , 2); //画虚线
    CGContextMoveToPoint(context, orginPoint.x, orginPoint.y);
    CGContextAddLineToPoint(context, toPoint.x, toPoint.y);
    CGContextStrokePath(context);
}














@end
