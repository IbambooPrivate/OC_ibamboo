//
//  View_Cartogram_Block.h
//  LSGS
//
//  Created by wzkj_macmini on 15/8/18.
//  Copyright (c) 2015年 wzkj_macmini. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef enum{
    Type_Block=0,
    Type_Line
} CartogramType;

@interface CartogramData:NSObject
@property(nonatomic) CGFloat value;
@property(nonatomic) int index;
@property(nonatomic,retain) NSString *text;
@property(nonatomic,retain) NSString *mark;
@end

IB_DESIGNABLE
@interface View_Cartogram : UIView
@property(nonatomic) IBInspectable CGFloat shadowHeight;
@property(retain,nonatomic) IBInspectable UIColor *axisColor;
@property(retain,nonatomic) IBInspectable UIColor *blockColor;
@property(retain,nonatomic) IBInspectable UIColor *markColor;
@property(retain,nonatomic) IBInspectable UIFont *markFont;
@property(nonatomic) IBInspectable int type;
@property(nonatomic) IBInspectable NSInteger maxBlockCount;
@property(retain,nonatomic) IBInspectable NSString *verticalTitle;
@property(retain,nonatomic) IBInspectable NSString *horizontalTitle;
@property(retain,nonatomic) IBInspectable UIColor *textColor;
@property(retain,nonatomic) IBInspectable UIFont *textFont;
@property(retain,nonatomic) NSMutableArray *dataArr;
@property(retain,nonatomic) NSMutableArray *levelLines;
@property(retain,nonatomic) IBInspectable UIColor *levelLineColor;

@property(nonatomic,readonly) CGFloat contentWidth;
@property(nonatomic,assign) IBInspectable CGFloat dotWidth;
@property(nonatomic) IBInspectable CGFloat contentOffset;
@end
