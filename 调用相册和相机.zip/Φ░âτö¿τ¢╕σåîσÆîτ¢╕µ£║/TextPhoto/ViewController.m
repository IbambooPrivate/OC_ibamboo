//
//  ViewController.m
//  TextPhoto
//
//  Created by 四川艺匠天诚科技有限公司 on 16/6/21.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate>
@property (nonatomic,strong) UIImage  *imge;
@property (nonatomic,assign) BOOL orSave;
@property (nonatomic,strong) UIAlertController *alertController;
@property (nonatomic,strong) UIImagePickerController *imagePicker;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
}

- (IBAction)IDbutton:(id)sender {
    
    _alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"" preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *photoAction = [UIAlertAction actionWithTitle:@"相册" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction *action) {
        [self imagePickerSetting];
        _imagePicker.sourceType  = UIImagePickerControllerSourceTypePhotoLibrary;
        _orSave = NO;
    }];
    UIAlertAction *cameraAction = [UIAlertAction actionWithTitle:@"相机" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction *action) {
        [self imagePickerSetting];
        _imagePicker.sourceType  = UIImagePickerControllerSourceTypeCamera;
        _orSave = YES;
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [_alertController addAction:photoAction];
    [_alertController addAction:cameraAction];
    [_alertController addAction:cancelAction];
    [self presentViewController:_alertController animated:YES completion:nil];
    
}


- (void)imagePickerSetting{
    _imagePicker = [UIImagePickerController new];
    _imagePicker.delegate = self;
    _imagePicker.editing = YES;
    _imagePicker.allowsEditing = YES;
    [self presentViewController:_imagePicker animated:YES completion:nil];
}


- (IBAction)photoButton:(id)sender {
    [self imagePickerSetting];
    _imagePicker.sourceType  = UIImagePickerControllerSourceTypePhotoLibrary;
    _orSave = NO;
    _imagePicker.sourceType  = UIImagePickerControllerSourceTypePhotoLibrary;


}
- (IBAction)cameraButton:(id)sender {
    
    _imagePicker.sourceType  = UIImagePickerControllerSourceTypeCamera;
    _orSave = YES;

}


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    _imge = info[@"UIImagePickerControllerEditedImage"];
    
    if(_orSave == YES)  {
        [self saveImage:_imge withName:@"currentImage.png"];
    }
    
    _imageView.image= self.imge;
    [picker dismissViewControllerAnimated:YES completion:nil];
    
}

//保存图片
- (void) saveImage:(UIImage *)currentImage withName:(NSString *)imageName
{
    NSData *imageData = UIImageJPEGRepresentation(currentImage, 0.5);
    // 获取沙盒目录
    NSString *fullPath = [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:imageName];
    // 将图片写入文件
    [imageData writeToFile:fullPath atomically:NO];
    //将选择的图片显示出来
    [_imageView setImage:[UIImage imageWithContentsOfFile:fullPath]];
    //将图片保存到disk
    UIImageWriteToSavedPhotosAlbum(currentImage, nil, nil, nil);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
