//
//  ViewController.h
//  TextPhoto
//
//  Created by 四川艺匠天诚科技有限公司 on 16/6/21.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

