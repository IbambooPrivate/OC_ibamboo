//
//  main.m
//  TextPhoto
//
//  Created by 四川艺匠天诚科技有限公司 on 16/6/21.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
