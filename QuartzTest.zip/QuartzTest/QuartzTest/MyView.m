//
//  MyView.m
//  QuartzTest
//
//  Created by heshun on 16/6/22.
//  Copyright © 2016年 deergod. All rights reserved.
//

#import "MyView.h"

typedef struct {
    CGFloat lengths[5];
    size_t count;
}Pattern;

static Pattern pattren[]={
    {{10.0,10.0},2},
    {{10,20,30},3},
    {{20,30,10},3}
};

@implementation MyView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
 */

- (void)drawRect:(CGRect)rect {
    //绘制星星
    
    CGContextRef con =UIGraphicsGetCurrentContext();
    CGContextSetRGBStrokeColor(con, 0, 1, 0, 1.0);
    CGContextSetRGBFillColor(con, 1, 0, 0, 1.0);
    CGPoint center=CGPointMake(200, 300);
    CGFloat radious=30;
    CGContextMoveToPoint(con, center.x+radious, center.y);
    for (int i=1; i<5; i++) {
        CGFloat x1=radious*cosf(M_PI*4*i/5.0);
        CGFloat y1=radious*sinf(M_PI*4*i/5.0);
        CGContextAddLineToPoint(con, center.x+x1, center.y+y1);
        
    }
    CGContextSetLineWidth(con, 5.0);
    CGContextClosePath(con);
    CGContextStrokePath(con);
    //下面代码可以设置绘图样式
    //CGContextDrawPath(con, kCGPathStroke);
    
    //绘制虚线
    CGContextSaveGState(con);
    CGContextSetLineDash(con, 10, pattren[1].lengths, pattren[1].count);
    CGContextSetLineWidth(con, 3.0);
    CGContextMoveToPoint(con, 20, 50);
    CGContextAddLineToPoint(con, 300, 50);
    CGContextStrokePath(con);
    CGContextRestoreGState(con);
    
    //绘制圆弧
    CGContextAddArc(con, 50, 50, 40, 0, M_PI/2.0, 1);
    CGContextSetLineWidth(con, 3);
    CGContextStrokePath(con);
    
    //绘制两段圆弧，第一段圆弧的终点与第二段圆弧的起点会连接一条直线
    CGContextAddArc(con, 50, 150, 40, 0, M_PI/2.0, 0);
    CGContextAddArc(con, 50, 150, 40, M_PI*3/2.0, M_PI, 1);
    CGContextStrokePath(con);
    
    
}


@end
