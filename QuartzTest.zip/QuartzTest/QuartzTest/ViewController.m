//
//  ViewController.m
//  QuartzTest
//
//  Created by heshun on 16/6/22.
//  Copyright © 2016年 deergod. All rights reserved.
//

#import "ViewController.h"
#import "MyView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    MyView *theView=[[MyView alloc]initWithFrame:self.view.bounds];
    theView.backgroundColor=[UIColor lightGrayColor];
    [self.view addSubview:theView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
