//
//  ViewController.h
//  test
//
//  Created by heshun on 16/6/15.
//  Copyright © 2016年 heshun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIView *cyanView;
@property(nonatomic,assign) BOOL panIndex;

@end

