//
//  ViewController.m
//  test
//
//  Created by heshun on 16/6/15.
//  Copyright © 2016年 heshun. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()//<UIDynamicItem>
@property(nonatomic,strong)UIDynamicAnimator *animator;//需要强引用
@property(nonatomic,strong)UIAttachmentBehavior *attachmentBehavior;//吸附
@property(nonatomic,strong)UIPushBehavior *pushBehavior;//推动
@property(nonatomic,strong)UICollisionBehavior *collisionBehavior;//碰撞
@property(nonatomic,strong)UIGravityBehavior* gravityBeahvior;//重力
@property(nonatomic,strong)UISnapBehavior *snapBehavior;//捕捉
@property(nonatomic,strong)UIDynamicItemBehavior *itemBehavior;//辅助的行为，用来在item层级设定一些参数，比如item的摩擦，阻力，角阻力，弹性密度和可允许的旋转等等
@property(nonatomic,strong)NSMutableArray *gestureArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.animator=[[UIDynamicAnimator alloc]initWithReferenceView:self.view];
    
    UIPanGestureRecognizer *attachment=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(attachmentGesture:)];
    
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGesture:)];
    
    UIPanGestureRecognizer *push=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(pushGesture:)];
    
    [self.view addGestureRecognizer:tap];
    //[self.view addGestureRecognizer:attachment];
    //[self.view addGestureRecognizer:push];
    
    self.gestureArray=[NSMutableArray arrayWithObjects:attachment,push, nil];
}

- (IBAction)click_attachment:(UIButton *)sender {
    if (_panIndex !=0) {
        self.panIndex=0;
    }
}

- (IBAction)click_push:(UIButton *)sender {
    if (_panIndex !=1) {
        self.panIndex=1;
    }
}

#pragma mark - 重力+碰撞

- (IBAction)click_gravity:(UIButton *)sender {
    //重力
    self.gravityBeahvior = [[UIGravityBehavior alloc] initWithItems:@[_cyanView]];
    [self.animator addBehavior:_gravityBeahvior];
    
    //3.碰撞
    self.collisionBehavior=[[UICollisionBehavior alloc]initWithItems:@[_cyanView]];
    self.collisionBehavior.translatesReferenceBoundsIntoBoundary=YES;
    
    self.itemBehavior=[[UIDynamicItemBehavior alloc]initWithItems:@[_cyanView]];
    //弹性系数
    self.itemBehavior.elasticity=0.6;
    //摩擦系数
    self.itemBehavior.friction=0.5;
    //阻力系数
    self.itemBehavior.resistance=0.2;
    [self.animator addBehavior:self.collisionBehavior];
    [self.animator addBehavior:self.itemBehavior];
    
}
#pragma mark - 捕捉
-(void)tapGesture:(UITapGestureRecognizer *)tapGesture{
    /**/
    //获取在控制器中点击的点的坐标
    CGPoint location=[tapGesture locationInView:self.view];
    self.snapBehavior=[[UISnapBehavior alloc]initWithItem:_cyanView snapToPoint:location];
    self.snapBehavior.damping=0.6;//剧烈程度
    [self.animator addBehavior:self.snapBehavior];
    
}

#pragma mark - 设置拖动手势是吸附还是推动仿真特效
-(void)setPanIndex:(BOOL)panIndex{
    if (_panIndex !=panIndex) {
        _panIndex=panIndex;
        int removeIndex= !panIndex;
        
        //NSUInteger count =self.view.gestureRecognizers.count;
        UIPanGestureRecognizer *removeGesture=self.gestureArray[removeIndex];
        [self.view removeGestureRecognizer:removeGesture];
        UIPanGestureRecognizer *selectedGesture=self.gestureArray[panIndex];
        [self.view addGestureRecognizer:selectedGesture];
        
        
        
    }
}

#pragma mark - 推动
-(void)pushGesture:(UIPanGestureRecognizer *)gesture{
    /**/
    //2.推动
    self.pushBehavior=[[UIPushBehavior alloc]initWithItems:@[_cyanView] mode:UIPushBehaviorModeContinuous];
    CGPoint velocity=[gesture velocityInView:self.view];
    CGFloat magnitude=sqrtf(velocity.x * velocity.x + velocity.y +velocity.y);
    self.pushBehavior.pushDirection=CGVectorMake(velocity.x/10, velocity.y/10);
    _pushBehavior.magnitude=magnitude/100;
    [self.animator addBehavior:self.pushBehavior];
    
    self.collisionBehavior=[[UICollisionBehavior alloc]initWithItems:@[_cyanView]];
    self.collisionBehavior.translatesReferenceBoundsIntoBoundary=YES;
    
    self.itemBehavior=[[UIDynamicItemBehavior alloc]initWithItems:@[_cyanView]];
    self.itemBehavior.elasticity=0.6;
    self.itemBehavior.friction=0.5;
    self.itemBehavior.resistance=0.5;
    [self.animator addBehavior:self.collisionBehavior];
    [self.animator addBehavior:self.itemBehavior];

}

#pragma mark - 吸附
-(void)attachmentGesture:(UIPanGestureRecognizer *)gesture{
    
    //1.吸附
    /**/
    CGPoint location=[gesture locationInView:self.view];
    CGPoint  boxLocation=[gesture locationInView:_cyanView];
    
    UIOffset centerOffset=UIOffsetMake(boxLocation.x-CGRectGetMidX(_cyanView.bounds), boxLocation.y-CGRectGetMidY(_cyanView.bounds));
    
    switch (gesture.state) {
        case UIGestureRecognizerStateBegan:{
            [self.animator removeAllBehaviors];
            self.attachmentBehavior=[[UIAttachmentBehavior alloc]initWithItem:_cyanView offsetFromCenter:centerOffset attachedToAnchor:location];
            self.attachmentBehavior.damping=0.5;
            self.attachmentBehavior.frequency=0.8;
            [self.animator addBehavior:self.attachmentBehavior];
            break;
        }
        case UIGestureRecognizerStateEnded:{
            [self.animator removeBehavior:self.attachmentBehavior];
            break;
        }
            
            
        default:
            [self.attachmentBehavior setAnchorPoint:location];
            break;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
