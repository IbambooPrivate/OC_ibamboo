//
//  BasicDrawViewController.m
//  CoreGraphicsDemo
//
//  Created by heshun on 16/6/22.
//  Copyright © 2016年 heshun. All rights reserved.
//

#import "BasicDrawViewController.h"
#import "BasicView.h"
@interface BasicDrawViewController ()

@end

@implementation BasicDrawViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    BasicView *theView=[[BasicView alloc]initWithFrame:self.view.bounds];
    theView.backgroundColor=[UIColor lightGrayColor];
    [self.view addSubview:theView];
}
bool orhidden=NO;
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    orhidden=!orhidden;
    [self.navigationController setNavigationBarHidden:orhidden];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
