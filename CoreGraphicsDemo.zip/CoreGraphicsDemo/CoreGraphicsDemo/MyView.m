//
//  MyView.m
//  CoreGraphicsDemo
//
//  Created by heshun on 16/6/17.
//  Copyright © 2016年 heshun. All rights reserved.
//

#import "MyView.h"
#import <CoreGraphics/CoreGraphics.h>
@implementation MyView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.

*/
- (void)drawRect:(CGRect)rect {
#pragma mark - 贝塞尔曲线
    
#pragma mark - 创建多边形
    UIColor *color=[UIColor redColor];
    [color set];
    UIBezierPath *aPath=[UIBezierPath bezierPath];
    aPath.lineWidth=5.0;
    aPath.lineCapStyle=kCGLineCapRound;
    aPath.lineJoinStyle=kCGLineCapRound;
    [aPath moveToPoint:CGPointMake(100.0, 0.0)];
    [aPath addLineToPoint:CGPointMake(200.0, 40.0)];
    [aPath addLineToPoint:CGPointMake(160, 140)];
    [aPath addLineToPoint:CGPointMake(40.0, 140)];
    [aPath addLineToPoint:CGPointMake(0.0, 40.0)];
    [aPath closePath];
    //画线
    //[aPath stroke];
    //填充
    [aPath fill];
    
#pragma mark - 创建矩形或椭圆
    UIColor *rectColor=[UIColor cyanColor];
    [rectColor set];
    //创建矩形
    //UIBezierPath *rectPath=[UIBezierPath bezierPathWithRect:CGRectMake(5, 150, 60, 60)];
    //创建椭圆（矩形内切圆）当传入的rect是一个长方形时，绘制的图像是一个内切椭圆。
    UIBezierPath *rectPath=[UIBezierPath bezierPathWithOvalInRect:CGRectMake(5, 150, 100, 60)];
    rectPath.lineWidth=5.0;
    rectPath.lineJoinStyle=kCGLineCapRound;
    rectPath.lineCapStyle=kCGLineCapRound;
    [rectPath closePath];
    [rectPath stroke];
    
#pragma mark - 创建圆弧
    UIColor *arcColor=[UIColor greenColor];
    [arcColor set];
    //最后一个参数clockwise：是否为顺时针，yes表示为顺时针，no表示逆时针
    UIBezierPath *arcPath=[UIBezierPath bezierPathWithArcCenter:CGPointMake(200, 200) radius:50 startAngle:0.0 endAngle:M_PI/2.0 clockwise:NO];
    arcPath.lineWidth=5.0;
    [arcPath stroke];
    
#pragma mark - 二次贝塞尔曲线
    UIColor *quadraticColor=[UIColor blackColor];
    [quadraticColor set];
    UIBezierPath *quadraticPath=[UIBezierPath bezierPath];
    quadraticPath.lineWidth=2.0;
    [quadraticPath moveToPoint:CGPointMake(30, 300)];
    [quadraticPath addQuadCurveToPoint:CGPointMake(160, 300) controlPoint:CGPointMake(40, 200)];
    [quadraticPath stroke];
    
    //两条切线
    [quadraticPath moveToPoint:CGPointMake(30, 300)];
    [quadraticPath addLineToPoint:CGPointMake(40, 200)];
    [quadraticPath addLineToPoint:CGPointMake(160, 300)];
    [quadraticPath stroke];
    
#pragma mark - 三次贝塞尔曲线
    UIColor *cubicColor=[UIColor purpleColor];
    [cubicColor set];
    UIBezierPath *cubicPath=[UIBezierPath bezierPath];
    cubicPath.lineWidth=2.0;
    [cubicPath moveToPoint:CGPointMake(30, 320)];
    [cubicPath addCurveToPoint:CGPointMake(200, 320) controlPoint1:CGPointMake(100, 270) controlPoint2:CGPointMake(100, 370)];
    [cubicPath stroke];
    
    //两条切线
    [cubicPath moveToPoint:CGPointMake(30, 320)];
    [cubicPath addLineToPoint:CGPointMake(100, 270)];
    [cubicPath stroke];
    [cubicPath moveToPoint:CGPointMake(200, 320)];
    [cubicPath addLineToPoint:CGPointMake(100, 370)];
    [cubicPath stroke];
    
#pragma mark - 使用Core Graphics修改Path
    /*
     UIBezierPath类只是CGPathRef数据类型和path绘图属性的一个封装。虽然通常我们可以用UIBezierPath类的方法去添加直线段和曲线段，UIBezierPath类还提供了一个属性CGPath，我们可以用来直接修改底层的path data type。如果我们希望用Core Graphics 框架函数去创建path，则我们要用到此属性。
     
     有两种方法可以用来修改和UIBezierPath对象相关的path。可以完全的使用Core Graphics函数去修改path，也可以使用Core Graphics函数和UIBezierPath函数混合去修改。第一种方法在某些方面相对来说比较容易。我们可以创建一个CGPathRef数据类型，并调用我们需要修改path信息的函数。
     下面的代码就是赋值一个新的CGPathRef给UIBezierPath对象。
     */
    
#pragma mark - 1.完全使用Core Graphics修改Path
    UIColor *coreColor=[UIColor yellowColor];
    [coreColor set];
    CGMutablePathRef thePath=CGPathCreateMutable();
    CGPathAddEllipseInRect(thePath, NULL, CGRectMake(10, 380, 100, 100));
    
    UIBezierPath *corePath=[UIBezierPath bezierPath];
    corePath.lineWidth=2.0;
    corePath.CGPath=thePath;
    corePath.usesEvenOddFillRule=YES;
    [corePath stroke];
    CGPathRelease(thePath);
    
#pragma mark - 2.使用Core Graphics函数和UIBezierPath函数混合去修改
    // 如果我们使用Core Graphics函数和UIBezierPath函数混合方法，我们必须小心的移动path 信息在两者之间。因为UIBezierPath类拥有自己底层的CGPathRef data type，我们不能简单的检索该类型并直接的修改它。相反，我们应该生成一个副本，然后修改此副本，然后赋值此副本给CGPath属性，如下代码
    UIColor * mixColor=[UIColor brownColor];
    [mixColor set];
    UIBezierPath *mixPath=[UIBezierPath bezierPath];
    CGPathRef onePath=mixPath.CGPath;
    CGMutablePathRef mutablePath=CGPathCreateMutableCopy(onePath);
    CGPathAddEllipseInRect(mutablePath, NULL, CGRectMake(150, 350, 80, 80));
    mixPath.CGPath=mutablePath;
    mixPath.lineWidth=2.0;
    [mixPath stroke];
    CGPathRelease(mutablePath);
    
#pragma mark - 渲染BezierPath对象的内容
    UIBezierPath *renderPath=[UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, 200, 100)];
    renderPath.lineWidth=5.0;
    [[UIColor blueColor] setStroke];
    [[UIColor cyanColor] setFill];
    CGContextRef con=UIGraphicsGetCurrentContext();
    
    CGContextSaveGState(con);
    CGContextTranslateCTM(con, 100, 450);
    [renderPath stroke];
    [renderPath fill];
    CGContextRestoreGState(con);
    
    
}


/*
-(void)drawLayer:(CALayer *)layer inContext:(CGContextRef)ctx{
    
}*/

@end
