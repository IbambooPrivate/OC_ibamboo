//
//  BasicView.m
//  CoreGraphicsDemo
//
//  Created by heshun on 16/6/22.
//  Copyright © 2016年 heshun. All rights reserved.
//

#import "BasicView.h"

@implementation BasicView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
 */
- (void)drawRect:(CGRect)rect {
    
#pragma mark - 添加椭圆
    /*
     //方法一
     CGContextRef con=UIGraphicsGetCurrentContext();
     CGContextAddEllipseInRect(con, CGRectMake(0, 0, 50, 100));
     CGContextSetFillColorWithColor(con, [UIColor redColor].CGColor);
     CGContextFillPath(con);
     
     //方法二
     UIBezierPath *p=[UIBezierPath bezierPathWithOvalInRect:CGRectMake(100, 100, 50, 100)];
     [[UIColor cyanColor] setFill];
     [p fill];
     */
    
#pragma mark - 画线绘图
    /*
     UIBezierPath *p=[UIBezierPath bezierPath];
     [p moveToPoint:CGPointMake(100, 100)];
     [p addLineToPoint:CGPointMake(100, 19)];
     [p setLineWidth:20];
     [p stroke];
     [[UIColor redColor]set];
     [p removeAllPoints];
     [p moveToPoint:CGPointMake(80, 25)];
     [p addLineToPoint:CGPointMake(100, 0)];
     [p addLineToPoint:CGPointMake(120, 25)];
     [p fill];
     [p removeAllPoints];
     [p moveToPoint:CGPointMake(90, 101)];
     [p addLineToPoint:CGPointMake(100, 90)];
     [p addLineToPoint:CGPointMake(110, 101)];
     [p fillWithBlendMode:kCGBlendModeClear alpha:1.0];
     */
    
#pragma mark - 绘制左右圆角矩形
    /*
     CGContextRef con=UIGraphicsGetCurrentContext();
     //设置线的颜色
     CGContextSetStrokeColorWithColor(con, [UIColor blackColor].CGColor);
     //设置线的宽度
     CGContextSetLineWidth(con, 3);
     //设置绘制的矩形以及圆角的位置和圆角半径
     UIBezierPath *p=[UIBezierPath bezierPathWithRoundedRect:CGRectMake(100, 100, 100, 100) byRoundingCorners:(UIRectCornerTopLeft|UIRectCornerTopRight) cornerRadii:CGSizeMake(10, 10)];
     [p stroke];
     */
    
#pragma mark - 奇偶规则的简单运用
    /*
     CGContextRef con=UIGraphicsGetCurrentContext();
     CGContextMoveToPoint(con, 90, 100);
     CGContextAddLineToPoint(con, 100, 90);
     CGContextAddLineToPoint(con, 110, 100);
     CGContextClosePath(con);
     CGContextAddRect(con, CGContextGetClipBoundingBox(con));
     
     // 使用奇偶规则，裁剪区域为矩形减去三角形区域
     CGContextEOClip(con);
     
     //绘制矩形 绘制完成时，底部三角形已被裁剪
     CGContextMoveToPoint(con, 100, 100);
     CGContextAddLineToPoint(con, 100, 19);
     CGContextSetLineWidth(con, 20);
     CGContextStrokePath(con);
     
     //绘制上方红色箭头
     CGContextSetFillColorWithColor(con, [UIColor redColor].CGColor);
     CGContextMoveToPoint(con, 80, 25);
     CGContextAddLineToPoint(con, 100, 0);
     CGContextAddLineToPoint(con, 120, 25);
     CGContextFillPath(con);
     */
    
#pragma mark - 渐变的简单运用
    /*
     CGContextRef con=UIGraphicsGetCurrentContext();
     CGContextSaveGState(con);
     CGContextMoveToPoint(con, 90, 100);
     CGContextAddLineToPoint(con, 100, 90);
     CGContextAddLineToPoint(con, 110, 100);
     CGContextClosePath(con);
     CGContextAddRect(con, CGContextGetClipBoundingBox(con));
     
     // 使用奇偶规则，裁剪区域为矩形减去三角形区域
     CGContextEOClip(con);
     CGContextMoveToPoint(con, 100, 100);
     CGContextAddLineToPoint(con, 100, 19);
     CGContextSetLineWidth(con, 20);
     // 使用路径的描边版本替换图形上下文的路径
     CGContextReplacePathWithStrokedPath(con);
     // 对路径的描边版本实施裁剪
     CGContextClip(con);
     
     //绘制渐变
     CGFloat locs[3]={0.0,0.5,1.0};
     CGFloat colors[12]={
     0.3,0.3,0.3,0.8,  //开始颜色，透明灰
     0.0,0.0,0.0,1.0,  //中间颜色，黑色
     0.3,0.3,0.3,0.8   //末尾颜色，透明灰
     };
     CGColorSpaceRef sp=CGColorSpaceCreateDeviceGray();
     CGGradientRef grad=CGGradientCreateWithColorComponents(sp, colors, locs, 3);
     CGContextDrawLinearGradient(con, grad, CGPointMake(89, 0), CGPointMake(111, 0), kCGGradientDrawsBeforeStartLocation);
     CGColorSpaceRelease(sp);
     CGGradientRelease(grad);
     CGContextRestoreGState(con);
     
     //绘制红色箭头
     CGContextSetFillColorWithColor(con, [UIColor redColor].CGColor);
     CGContextMoveToPoint(con, 80, 25);
     CGContextAddLineToPoint(con, 100, 0);
     CGContextAddLineToPoint(con, 120, 25);
     
     CGContextFillPath(con);
     */
    
#pragma mark - 模板
    /*
     CGContextRef con=UIGraphicsGetCurrentContext();
     CGContextSaveGState(con);
     CGContextMoveToPoint(con, 90, 100);
     CGContextAddLineToPoint(con, 100, 90);
     CGContextAddLineToPoint(con, 110, 100);
     CGContextClosePath(con);
     CGContextAddRect(con, CGContextGetClipBoundingBox(con));
     
     // 使用奇偶规则，裁剪区域为矩形减去三角形区域
     CGContextEOClip(con);
     CGContextMoveToPoint(con, 100, 100);
     CGContextAddLineToPoint(con, 100, 19);
     CGContextSetLineWidth(con, 20);
     // 使用路径的描边版本替换图形上下文的路径
     CGContextReplacePathWithStrokedPath(con);
     // 对路径的描边版本实施裁剪
     CGContextClip(con);
     
     //绘制渐变
     CGFloat locs[3]={0.0,0.5,1.0};
     CGFloat colors[12]={
     0.3,0.3,0.3,0.8,  //开始颜色，透明灰
     0.0,0.0,0.0,1.0,  //中间颜色，黑色
     0.3,0.3,0.3,0.8   //末尾颜色，透明灰
     };
     CGColorSpaceRef sp=CGColorSpaceCreateDeviceGray();
     CGGradientRef grad=CGGradientCreateWithColorComponents(sp, colors, locs, 3);
     CGContextDrawLinearGradient(con, grad, CGPointMake(89, 0), CGPointMake(111, 0), kCGGradientDrawsBeforeStartLocation);
     CGColorSpaceRelease(sp);
     CGGradientRelease(grad);
     CGContextRestoreGState(con);
     
     //绘制红蓝相间的三角形
     CGColorSpaceRef sp2=CGColorSpaceCreatePattern(NULL);
     CGContextSetFillColorSpace(con, sp2);
     CGPatternCallbacks callback={0,&drawStripes,NULL};
     CGAffineTransform tr=CGAffineTransformIdentity;
     //创建模板，一个模板是在一个矩形元中的绘图。参数：
     //参数2，矩形元的尺寸
     //参数3，一个应用到矩形元的变换参数（第三个参数）；在这种情况下，我们不需要变换做什么工作，所以我们应用了一个恒等变换
     //参数4，参数5，是矩形元原始点之间的间隙
     //参数8，回调函数的工作是向矩形元绘制模板。第八个参数是一个指向CGPatternCallbacks结构体的指针。这个结构体由数字0和两个指向函数的指针构成。第一个函数指针指向的函数当模板被绘制到矩形元中被调用，第二个函数指针指向的函数当模板被释放后调用。第二个函数指针我们没有指定，它的存在主要是为了内存管理的需要。但在这个简单的例子中，我们并不需要。
     CGPatternRef patt=CGPatternCreate(NULL, CGRectMake(0, 0, 4, 4), tr, 4, 4, kCGPatternTilingConstantSpacingMinimalDistortion, YES, &callback);
     CGFloat alph=1.0;
     //设置填充模板
     CGContextSetFillPattern(con, patt, &alph);
     CGPatternRelease(patt);
     
     
     CGContextMoveToPoint(con, 80, 25);
     CGContextAddLineToPoint(con, 100, 0);
     CGContextAddLineToPoint(con, 120, 25);
     
     CGContextFillPath(con);
     */
    
#pragma mark - 旋转变换
    /**/
     UIGraphicsBeginImageContextWithOptions(CGSizeMake(400, 100), NO, 0);
     
     CGContextRef con=UIGraphicsGetCurrentContext();
     CGContextSaveGState(con);
     CGContextMoveToPoint(con, 90, 100);
     CGContextAddLineToPoint(con, 100, 90);
     CGContextAddLineToPoint(con, 110, 100);
     CGContextMoveToPoint(con, 110, 100);
     CGContextAddLineToPoint(con, 100, 90);
     CGContextAddLineToPoint(con, 90, 100);
     CGContextClosePath(con);
     CGContextAddRect(con, CGContextGetClipBoundingBox(con));
     
     // 使用奇偶规则，裁剪区域为矩形减去三角形区域
     CGContextEOClip(con);
     CGContextMoveToPoint(con, 100, 100);
     CGContextAddLineToPoint(con, 100, 19);
     CGContextSetLineWidth(con, 20);
     // 使用路径的描边版本替换图形上下文的路径
     CGContextReplacePathWithStrokedPath(con);
     // 对路径的描边版本实施裁剪
     CGContextClip(con);
     
     //绘制渐变
     CGFloat locs[3]={0.0,0.5,1.0};
     CGFloat colors[12]={
     0.3,0.3,0.3,0.8,  //开始颜色，透明灰
     0.0,0.0,0.0,1.0,  //中间颜色，黑色
     0.3,0.3,0.3,0.8   //末尾颜色，透明灰
     };
     CGColorSpaceRef sp=CGColorSpaceCreateDeviceGray();
     CGGradientRef grad=CGGradientCreateWithColorComponents(sp, colors, locs, 3);
     CGContextDrawLinearGradient(con, grad, CGPointMake(89, 0), CGPointMake(111, 0), kCGGradientDrawsBeforeStartLocation);
     CGColorSpaceRelease(sp);
     CGGradientRelease(grad);
     CGContextRestoreGState(con);
     
     //绘制红蓝相间的三角形
     CGColorSpaceRef sp2=CGColorSpaceCreatePattern(NULL);
     CGContextSetFillColorSpace(con, sp2);
     CGColorSpaceRelease(sp2);
     CGPatternCallbacks callback={0,&drawStripes,NULL};
     CGAffineTransform tr=CGAffineTransformIdentity;
     //创建模板，一个模板是在一个矩形元中的绘图。参数：
     //参数2，矩形元的尺寸
     //参数3，一个应用到矩形元的变换参数（第三个参数）；在这种情况下，我们不需要变换做什么工作，所以我们应用了一个恒等变换
     //参数4，参数5，是矩形元原始点之间的间隙
     //参数8，回调函数的工作是向矩形元绘制模板。第八个参数是一个指向CGPatternCallbacks结构体的指针。这个结构体由数字0和两个指向函数的指针构成。第一个函数指针指向的函数当模板被绘制到矩形元中被调用，第二个函数指针指向的函数当模板被释放后调用。第二个函数指针我们没有指定，它的存在主要是为了内存管理的需要。但在这个简单的例子中，我们并不需要。
     CGPatternRef patt=CGPatternCreate(NULL, CGRectMake(0, 0, 4, 4), tr, 4, 4, kCGPatternTilingConstantSpacingMinimalDistortion, YES, &callback);
     CGFloat alph=1.0;
     //设置填充模板
     CGContextSetFillPattern(con, patt, &alph);
     CGPatternRelease(patt);
     
     CGContextMoveToPoint(con, 80, 25);
     CGContextAddLineToPoint(con, 100, 0);
     CGContextAddLineToPoint(con, 120, 25);
     CGContextFillPath(con);
     
     UIImage *im=UIGraphicsGetImageFromCurrentImageContext();
     UIGraphicsEndImageContext();
     con = UIGraphicsGetCurrentContext();
     [im drawAtPoint:CGPointMake(0, 0)];
     for (int i=0; i<12; i++) {
     //CGContextRotateCTM(CGContextRef c, CGFloat angle)方法可以相对原点旋转上下文坐标系
     //CGContextTranslateCTM(CGContextRef c, CGFloat tx, CGFloat ty)方法可以相对原点平移上下文坐标系
     //CGContextScaleCTM(CGContextRef c, CGFloat sx, CGFloat sy)方法可以缩放上下文坐标系
     CGContextTranslateCTM(con, 100, 100);
     CGContextRotateCTM(con, 30*M_PI/180.0);
     CGContextTranslateCTM(con, -100, -100);
     [im drawAtPoint:CGPointMake(0, 0)];
     
     }
     

 

}

void drawStripes (void *info, CGContextRef con) {
    CGContextSetFillColorWithColor(con, [UIColor redColor].CGColor);
    CGContextFillRect(con, CGRectMake(0, 0, 4, 4));
    CGContextSetFillColorWithColor(con, [UIColor blueColor].CGColor);
    CGContextFillRect(con, CGRectMake(0, 0, 4, 2));
    
}

@end
