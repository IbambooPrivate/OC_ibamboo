//
//  ViewController.m
//  CoreGraphicsDemo
//
//  Created by heshun on 16/6/17.
//  Copyright © 2016年 heshun. All rights reserved.
//

#import "ViewController.h"
#import "MyView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    MyView *theView=[[MyView alloc]initWithFrame:self.view.bounds];
    theView.backgroundColor=[UIColor lightGrayColor];
    [self.view addSubview:theView];
    
    //UIImage *image=[UIImage imageNamed:@"icon_clock"];
    //CGSize size=[image size];
    
#pragma mark - 平移
    /*

    //解释一下UIGraphicsBeginImageContextWithOptions函数参数的含义：第一个参数表示所要创建的图片的尺寸；第二个参数用来指定所生成图片的背景是否为不透明，如上我们使用YES而不是NO，则我们得到的图片背景将会是黑色，显然这不是我想要的；第三个参数指定生成图片的缩放因子，这个缩放因子与UIImage的scale属性所指的含义是一致的。传入0则表示让图片的缩放因子根据屏幕的分辨率而变化，所以我们得到的图片不管是在单分辨率还是视网膜屏上看起来都会很好。
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(size.width*2, size.height), NO, 0);
    [image drawAtPoint:CGPointMake(0, 0)];
    [image drawAtPoint:CGPointMake(size.width, 0)];
    
    UIImage *im=UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    UIImageView *iv=[[UIImageView alloc] initWithImage:im];
    [self.view addSubview:iv];
    iv.center =self.view.center;
    */
    
#pragma mark - 缩放
    /*

    UIGraphicsBeginImageContextWithOptions(CGSizeMake(size.width*2, size.height*2), NO, 0);
    [image drawInRect:CGRectMake(0, 0, size.width*2, size.height*2)];
    [image drawInRect:CGRectMake(size.width/2.0, size.height/2.0, size.width, size.height) blendMode:kCGBlendModeMultiply alpha:1.0];
    UIImage *im=UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    UIImageView *iv=[[UIImageView alloc] initWithImage:im];
    [self.view addSubview:iv];
    iv.center =self.view.center;
    */

#pragma mark - 裁剪 仅显示右半边
    /*

    UIGraphicsBeginImageContextWithOptions(CGSizeMake(size.width/2, size.height*2), NO, 0);
    [image drawAtPoint:CGPointMake(-size.width/2.0, 0)];
    UIImage *im=UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    UIImageView *iv=[[UIImageView alloc] initWithImage:im];
    [self.view addSubview:iv];
    iv.center =self.view.center;
    */
    
    
#pragma mark - 将图片拆分成两半，并分别绘制在上下文的左右两边
    /*
    //方法一：使用flip函数
    CGImageRef marsCG=[image CGImage];
    CGSize sizeCG=CGSizeMake(CGImageGetWidth(marsCG), CGImageGetHeight(marsCG));
    
    // 抽取图片的左右半边
    CGImageRef marsLeft=CGImageCreateWithImageInRect([image CGImage], CGRectMake(0, 0, sizeCG.width/2.0, sizeCG.height));
    CGImageRef marsRight=CGImageCreateWithImageInRect([image CGImage], CGRectMake(sizeCG.width/2.0, 0, sizeCG.width/2.0, sizeCG.height));
    // 将每一个CGImage绘制到图形上下文中
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(size.width*1.5, size.height), NO, 0);
    CGContextRef con=UIGraphicsGetCurrentContext();
    CGContextDrawImage(con, CGRectMake(0, 0, size.width/2.0, size.height), flip(marsLeft));
    CGContextDrawImage(con, CGRectMake(size.width, 0, size.width/2.0, size.height), flip(marsRight));
    UIImage *im=UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    CGImageRelease(marsRight);
    CGImageRelease(marsLeft);
    UIImageView *iv=[[UIImageView alloc]initWithImage:im];
    iv.frame=CGRectMake(0, 300, 200, 200);
    [self.view addSubview:iv];
    */
    
    /*
    //方法二：在绘图之前将CGImage包装进UIImage中
    CGImageRef marsCG=[image CGImage];
    CGSize sizeCG=CGSizeMake(CGImageGetWidth(marsCG), CGImageGetHeight(marsCG));
    CGImageRef marsLeft=CGImageCreateWithImageInRect([image CGImage], CGRectMake(0, 0, sizeCG.width/2.0, sizeCG.height));
    CGImageRef marsRight=CGImageCreateWithImageInRect([image CGImage], CGRectMake(sizeCG.width/2.0, 0, sizeCG.width/2.0, sizeCG.height));
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(size.width*1.5, size.height), NO, 0);
    [[UIImage imageWithCGImage:marsLeft scale:[image scale] orientation:UIImageOrientationUp] drawAtPoint:CGPointMake(0, 0)];
    [[UIImage imageWithCGImage:marsRight scale:[image scale] orientation:UIImageOrientationUp] drawAtPoint:CGPointMake(size.width, 0)];
    UIImage *im=UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    CGImageRelease(marsRight);
    CGImageRelease(marsLeft);
    UIImageView *iv=[[UIImageView alloc]initWithImage:im];
    iv.frame=CGRectMake(0, 300, 200, 200);
    [self.view addSubview:iv];
    */
    
    
    
    
    
}

CGImageRef flip (CGImageRef im) {
    CGSize sz=CGSizeMake(CGImageGetWidth(im), CGImageGetHeight(im));
    UIGraphicsBeginImageContextWithOptions(sz, NO, 0);
    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, sz.width, sz.height), im);
    CGImageRef result=[UIGraphicsGetImageFromCurrentImageContext() CGImage];
    UIGraphicsEndImageContext();
    return result;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
