//
//  CurveViewController.m
//  CoreGraphicsDemo
//
//  Created by heshun on 16/6/22.
//  Copyright © 2016年 heshun. All rights reserved.
//

#import "CurveViewController.h"
#import "MyView.h"
@interface CurveViewController ()

@end

@implementation CurveViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    MyView *theView=[[MyView alloc]initWithFrame:self.view.bounds];
    theView.backgroundColor=[UIColor lightGrayColor];
    [self.view addSubview:theView];
}
bool orobserve=NO;
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    orobserve=!orobserve;
    [self.navigationController setNavigationBarHidden:orobserve];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
