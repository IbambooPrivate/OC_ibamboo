//
//  ViewController.m
//  demo
//
//  Created by 四川艺匠天诚科技有限公司 on 16/10/9.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import "ViewController.h"
#import "TwoViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)viewWillAppear:(BOOL)animated{
    
}
- (IBAction)oneBtn:(id)sender {
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    TwoViewController *two = [sb instantiateViewControllerWithIdentifier:@"TwoViewController"];
    [two backStr:^(NSString *str) {
        NSLog(@"===&%@",str);
        _oneLab.text = @"123";
    }];

    [self.navigationController pushViewController:two animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
