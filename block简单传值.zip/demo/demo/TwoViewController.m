//
//  TwoViewController.m
//  demo
//
//  Created by 四川艺匠天诚科技有限公司 on 16/10/9.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import "TwoViewController.h"

@interface TwoViewController ()

@end

@implementation TwoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (IBAction)twoBtn:(id)sender {
    if (self.str) {
        self.str(@"123");
    }
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)backStr:(void (^)(NSString *))block{
    self.str = block;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
