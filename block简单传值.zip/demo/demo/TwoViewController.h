//
//  TwoViewController.h
//  demo
//
//  Created by 四川艺匠天诚科技有限公司 on 16/10/9.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^BackStr)(NSString *str);
@interface TwoViewController : UIViewController


@property (weak, nonatomic) IBOutlet UILabel *teoLabe;
@property (copy, nonatomic) BackStr str;
- (void)backStr:(void(^)(NSString *str))block;

@end
