//
//  ViewController.h
//  demo
//
//  Created by 四川艺匠天诚科技有限公司 on 16/10/9.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *oneLab;

@end

