//
//  ViewController.m
//  blur
//
//  Created by 四川艺匠天诚科技有限公司 on 16/6/28.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+ImageEffects.h"
#import <Accelerate/Accelerate.h>
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //是UIimage调用这个api
    //- (UIImage *)applyBlurWithRadius:(CGFloat)blurRadius tintColor:(UIColor *)tintColor saturationDeltaFactor:(CGFloat)saturationDeltaFactor maskImage:(UIImage *)maskImage;

   [_imageView setImage:[[UIImage imageNamed:@"huba.jpeg"] applyBlurWithRadius:20 tintColor:[UIColor colorWithWhite:1 alpha:0.2] saturationDeltaFactor:1.8 maskImage:nil]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
