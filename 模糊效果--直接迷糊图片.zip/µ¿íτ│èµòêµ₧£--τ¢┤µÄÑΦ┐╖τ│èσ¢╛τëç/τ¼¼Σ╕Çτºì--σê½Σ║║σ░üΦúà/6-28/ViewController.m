//
//  ViewController.m
//  6-28
//
//  Created by 四川艺匠天诚科技有限公司 on 16/6/28.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

#import "ViewController.h"
#import "UIImageView+LBBlurredImage.h"
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imgeView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [_imgeView setImageToBlur:[UIImage imageNamed:@"huoying4.jpg"] blurRadius:10 completionBlock:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
